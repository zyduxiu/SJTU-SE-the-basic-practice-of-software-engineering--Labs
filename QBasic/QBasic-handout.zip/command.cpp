#include "command.h"

command::command()
{

}
