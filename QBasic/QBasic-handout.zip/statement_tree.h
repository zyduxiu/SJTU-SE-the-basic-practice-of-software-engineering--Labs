#ifndef STATEMENT_TREE_H
#define STATEMENT_TREE_H


class statement_tree
{
public:
    statement_tree();
};

#endif // STATEMENT_TREE_H
