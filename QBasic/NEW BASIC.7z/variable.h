#ifndef VARIABLE_H
#define VARIABLE_H
#include <string>
#include "expression.h"



#endif // VARIABLE_H
