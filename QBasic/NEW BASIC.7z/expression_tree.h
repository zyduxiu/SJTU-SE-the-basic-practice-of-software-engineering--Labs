#ifndef EXPRESSION_TREE_H
#define EXPRESSION_TREE_H
#include "expression.h"

class expression_tree
{
private:
   // expression *root;
public:
    expression_tree(){
      //  root->left=nullptr;
     //   root->right=nullptr;
    }

};

#endif // EXPRESSION_TREE_H
